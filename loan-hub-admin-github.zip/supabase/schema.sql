-- Loan Hub USA - Clients table
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  landing_page text not null default 'US Advance America Style Page',
  token_expiry_days integer not null default 30,
  access_token text unique,
  status text not null default 'Active',
  created_at timestamptz not null default now()
);

alter table public.clients enable row level security;

-- Authenticated users can manage the table.
-- For a single-admin dashboard, keep Supabase Auth restricted to your admin account.
drop policy if exists "authenticated users can read clients" on public.clients;
create policy "authenticated users can read clients"
on public.clients for select
to authenticated
using (true);

drop policy if exists "authenticated users can insert clients" on public.clients;
create policy "authenticated users can insert clients"
on public.clients for insert
to authenticated
with check (true);

drop policy if exists "authenticated users can update clients" on public.clients;
create policy "authenticated users can update clients"
on public.clients for update
to authenticated
using (true)
with check (true);

drop policy if exists "authenticated users can delete clients" on public.clients;
create policy "authenticated users can delete clients"
on public.clients for delete
to authenticated
using (true);
