# Loan Hub USA - Admin Clients

Simple static admin dashboard designed to deploy on Vercel and use Supabase as the backend.

## 1. Supabase

Create a Supabase project.

Open **SQL Editor** and run:

`supabase/schema.sql`

Then create the admin account in:

**Authentication → Users → Add user**

Use your admin email and a new password. Do not put the password in GitHub.

## 2. Configure frontend

Open:

`js/config.js`

Replace:

```js
window.SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
```

with your Supabase Project URL and publishable/anon key.

The publishable/anon key is intended for browser use. Never put a Supabase service-role/secret key in this project.

## 3. GitHub

Create a new repository and upload all project files.

## 4. Vercel

Import the GitHub repository into Vercel.

No build command is required because this is a static HTML project.

The login page is:

`/`

The admin page is:

`/admin-clients.html`

## Easy editing

Most visual changes are in:

`css/style.css`

Client fields and table columns are in:

`admin-clients.html`

Supabase connection is in:

`js/config.js`

Database structure/security is in:

`supabase/schema.sql`
