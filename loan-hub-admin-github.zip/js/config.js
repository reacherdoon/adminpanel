/*
  EASY EDIT:
  1. Create a Supabase project.
  2. Copy Project URL and Publishable/Anon key from Supabase.
  3. Paste them below.
*/
window.SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
