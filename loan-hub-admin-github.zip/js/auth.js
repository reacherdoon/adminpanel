const client = supabase.createClient(
  window.SUPABASE_URL,
  window.SUPABASE_ANON_KEY
);

const form = document.getElementById("loginForm");
const message = document.getElementById("loginMessage");

(async function checkExistingSession() {
  const { data } = await client.auth.getSession();
  if (data.session) {
    window.location.href = "./admin-clients.html";
  }
})();

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (window.SUPABASE_URL.includes("YOUR_")) {
    message.textContent = "Add your Supabase URL and key in js/config.js first.";
    return;
  }

  message.textContent = "Signing in...";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const { error } = await client.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    message.textContent = error.message;
    return;
  }

  window.location.href = "./admin-clients.html";
});
