const client = supabase.createClient(
  window.SUPABASE_URL,
  window.SUPABASE_ANON_KEY
);

const form = document.getElementById("clientForm");
const body = document.getElementById("clientsBody");
const formMessage = document.getElementById("formMessage");
const searchInput = document.getElementById("searchInput");
const saveBtn = document.getElementById("saveBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");

let allClients = [];

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function makeToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(18));
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}

async function requireLogin() {
  const { data } = await client.auth.getSession();
  if (!data.session) {
    window.location.href = "./index.html";
    return null;
  }
  return data.session;
}

async function loadClients() {
  const { data, error } = await client
    .from("clients")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    body.innerHTML = `<tr><td colspan="7" class="empty">${escapeHtml(error.message)}</td></tr>`;
    return;
  }

  allClients = data || [];
  renderClients();
}

function renderClients() {
  const q = searchInput.value.trim().toLowerCase();

  const clients = allClients.filter(row =>
    [row.full_name, row.email, row.landing_page, row.status]
      .some(v => String(v ?? "").toLowerCase().includes(q))
  );

  if (!clients.length) {
    body.innerHTML = '<tr><td colspan="7" class="empty">No clients found.</td></tr>';
    return;
  }

  body.innerHTML = clients.map(row => `
    <tr>
      <td>${escapeHtml(row.full_name)}</td>
      <td>${escapeHtml(row.email)}</td>
      <td>${escapeHtml(row.landing_page)}</td>
      <td>${escapeHtml(row.token_expiry_days)} days</td>
      <td><span class="status">${escapeHtml(row.status)}</span></td>
      <td>${escapeHtml(row.access_token || "")}</td>
      <td>
        <button class="action-btn" onclick="editClient('${row.id}')">Edit</button>
        <button class="action-btn delete" onclick="deleteClient('${row.id}')">Delete</button>
      </td>
    </tr>
  `).join("");
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  formMessage.textContent = "Saving...";

  const id = document.getElementById("clientId").value;
  const payload = {
    full_name: document.getElementById("clientName").value.trim(),
    email: document.getElementById("clientEmail").value.trim(),
    landing_page: document.getElementById("landingPage").value,
    token_expiry_days: Number(document.getElementById("tokenExpiry").value),
    status: document.getElementById("status").value
  };

  if (!id) {
    payload.access_token = makeToken();
  }

  const result = id
    ? await client.from("clients").update(payload).eq("id", id)
    : await client.from("clients").insert(payload);

  if (result.error) {
    formMessage.textContent = result.error.message;
    return;
  }

  formMessage.textContent = id ? "Client updated." : "Client added.";
  resetForm();
  await loadClients();
});

window.editClient = function(id) {
  const row = allClients.find(item => item.id === id);
  if (!row) return;

  document.getElementById("clientId").value = row.id;
  document.getElementById("clientName").value = row.full_name || "";
  document.getElementById("clientEmail").value = row.email || "";
  document.getElementById("landingPage").value = row.landing_page || "US Advance America Style Page";
  document.getElementById("tokenExpiry").value = String(row.token_expiry_days || 30);
  document.getElementById("status").value = row.status || "Active";

  saveBtn.textContent = "Update Client";
  cancelEditBtn.classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
};

window.deleteClient = async function(id) {
  const row = allClients.find(item => item.id === id);
  if (!row) return;

  if (!confirm(`Delete ${row.full_name}?`)) return;

  const { error } = await client.from("clients").delete().eq("id", id);

  if (error) {
    formMessage.textContent = error.message;
    return;
  }

  await loadClients();
};

function resetForm() {
  form.reset();
  document.getElementById("clientId").value = "";
  document.getElementById("tokenExpiry").value = "30";
  document.getElementById("landingPage").value = "US Advance America Style Page";
  document.getElementById("status").value = "Active";
  saveBtn.textContent = "Add Client";
  cancelEditBtn.classList.add("hidden");
}

cancelEditBtn.addEventListener("click", resetForm);
searchInput.addEventListener("input", renderClients);

document.getElementById("logoutBtn").addEventListener("click", async () => {
  await client.auth.signOut();
  window.location.href = "./index.html";
});

(async function init() {
  const session = await requireLogin();
  if (session) {
    await loadClients();
  }
})();
